package com.example.try_with_andstudio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
